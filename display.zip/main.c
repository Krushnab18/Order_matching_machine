#include"display.h"
#include<stdio.h>

int main(){
    Order order;
    display(&order);
    return 0;
}